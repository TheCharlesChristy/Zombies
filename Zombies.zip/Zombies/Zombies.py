import time
import pygame
import IntroScreen
import random

pygame.init()


    


 
clock = pygame.time.Clock()

win = pygame.display.set_mode((1000, 750))

pygame.display.set_caption("Zombiessss")

 
desertMap = pygame.image.load("desert.PNG")
cityMap = pygame.image.load("City.png")
grassMap = pygame.image.load("grassland.png")

font1 = pygame.font.SysFont("comicsans", 30, True)
map = "DesertMap"
IntroScreen = IntroScreen.introscreen()
Player_sprites = pygame.sprite.Group()
Zombie_sprites = pygame.sprite.Group()
Holes = pygame.sprite.Group()
Walls = pygame.sprite.Group()
Wreckers = pygame.sprite.Group()


 

class Player(pygame.sprite.Sprite):

    def __init__(self, chosenCharacter):
        self.runthrough = 0
        self.IsInvincible = False
        pygame.sprite.Sprite.__init__(self)
        self.life = 3 #everycharacters variables
        self.isright = False
        self.isleft = False
        self.isup = False
        self.isdown = False
        self.walkCount = 0
       
        if chosenCharacter == "Jake":
            self.speed = 3
            self.width = 99
            self.height = 99
            self.x = 450
            self.y = 307
            self.spawnpos = ((450, 307))
            self.canBreakWall = True
            self.canBeInjured = False
            self.canTP = False
            self.sf = 0.5
 
        if chosenCharacter == "Noah":
            self.speed = 7
            self.width = 59.3
            self.height = 60
            self.x = 470
            self.y = 335
            self.spawnpos = ((470, 335))
            self.canBreakWall = False
            self.canBeInjured = True
            self.canTP = False
            self.sf = 0.75
 
        if chosenCharacter == "Will":
            self.speed = 5
            self.width = 79.3
            self.height = 80
            self.x = 460
            self.y = 317
            self.spawnpos = ((460, 317))
            self.canBreakWall = False
            self.canBeInjured = False
            self.canTP = True
            self.sf = 0.6
        self.rect = pygame.Rect(self.x, self.y, self.width * self.sf, self.height * self.sf)
        Player_sprites.add(self)

 
    def getSprite(self, chosenCharacter):
        self.chosenCharacter = chosenCharacter
        self.spriteList = []
        self.fileName = str(self.chosenCharacter + ".png")
        self.spriteSheet = pygame.image.load(self.fileName)
        xblocks = 0        
        yblocks = 0
        for yblocks in range (4):
            for xblocks in range (3):
                sprite = pygame.Surface((self.width, self.height))
                sprite.set_colorkey((255,255,255))
                sprite.blit(self.spriteSheet,(0,0),(xblocks*self.width, yblocks*self.height, self.width, self.height))
                smallsprite = pygame.transform.scale(sprite, (int(self.width * self.sf), int(self.height * self.sf)))
                self.spriteList.append(smallsprite)
        self.runthrough = 1
        return self.spriteList
   
    
    def draw(self):
        if self.runthrough == 0:
            self.spriteList = self.getSprite(chosenCharacter)
        if self.walkCount + 1 >= 42:
            self.walkCount = 0
        walkDown = [self.spriteList[0], self.spriteList[2], self.spriteList[0], self.spriteList[2], self.spriteList[0], self.spriteList[2], ]
        walkLeft = [self.spriteList[3], self.spriteList[5], self.spriteList[3], self.spriteList[5], self.spriteList[3], self.spriteList[5], ]
        walkRight = [self.spriteList[6], self.spriteList[8], self.spriteList[6], self.spriteList[8], self.spriteList[6], self.spriteList[8], ]
        walkUp = [self.spriteList[9], self.spriteList[11], self.spriteList[9], self.spriteList[11], self.spriteList[9], self.spriteList[11], ]
        if self.isdown:
            self.image = walkDown[self.walkCount//7]
            self.walkCount += 1
        elif self.isup:
            self.image = walkUp[self.walkCount//7]
            self.walkCount += 1
        elif self.isright:
            self.image = walkRight[self.walkCount//7]
            self.walkCount += 1
        elif self.isleft:
            self.image = walkLeft[self.walkCount//7]
            self.walkCount += 1
        else:
            self.image = self.spriteList[1]
        
    
    def update(self):
        if not self.IsInvincible:
            self.count = 0
            if pygame.sprite.spritecollideany(self, Holes):
                self.life -= 0
                self.rect.x = self.x
                self.rect.y = self.y
                self.IsInvincible = True
            if pygame.sprite.spritecollideany(self, Zombie_sprites):
                self.life -= 0
                self.rect.x = self.x
                self.rect.y = self.y
                self.IsInvincible = True
        else:
            self.count += 1
            if self.count == 42 * 3:
                self.IsInvincible = False
        if pygame.sprite.spritecollideany(self, Walls):
            Sprite = pygame.sprite.spritecollideany(self, Walls)
            print(Sprite.type)
            if Sprite.type == "BouncyHorizontal":
                for i in range(self.height):
                    if Sprite.rect.y > self.rect.y:
                        self.rect.y -= 1
                    elif Sprite.rect.y < self.rect.y:
                        self.rect.y += 1
                    elif Sprite.rect.x > self.rect.x:
                        self.rect.x -= 1
                    else:
                        self.rect.x += 1
            elif Sprite.type == "BouncyVertical":
                for i in range(self.height):
                    if Sprite.rect.y > self.rect.y:
                        self.rect.y -= 1
                    elif Sprite.rect.y < self.rect.y:
                        self.rect.y += 1
                    elif Sprite.rect.x > self.rect.x:
                        self.rect.x -= 1
                    else:
                        self.rect.x += 1
            elif Sprite.type == "NormalHorizontal":
                if Sprite.rect.y > self.rect.y:
                    self.rect.y -= 1
                elif Sprite.rect.y < self.rect.y:
                    self.rect.y += 1
                elif Sprite.rect.x > self.rect.x:
                    self.rect.x -= 1
                else:
                    self.rect.x += 1
            else:
                if Sprite.rect.y > self.rect.y:
                    self.rect.y -= 1
                elif Sprite.rect.y < self.rect.y:
                    self.rect.y += 1
                elif Sprite.rect.x > self.rect.x:
                    self.rect.x -= 1
                else:
                    self.rect.x += 1
        
    def Down(self):
        self.rect.y += self.speed
        self.isleft = False
        self.isright = False
        self.isup = False
        self.isdown = True
    def Notmoving(self):
        self.isleft = False
        self.isright = False
        self.isup = False
        self.isdown = False
        self.walkCount = 0
    def Right(self):
        self.rect.x += self.speed
        self.isleft = False
        self.isright = True
        self.isup = False
        self.isdown = False
    def Up(self):
        self.rect.y -= self.speed
        self.isleft = False
        self.isright = False
        self.isup = True
        self.isdown = False
    def Left(self):
        self.rect.x -= self.speed
        self.isleft = True
        self.isright = False
        self.isup = False
        self.isdown = False
class Zombie(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.runthrough = 0
        self.isright = False
        self.isleft = False
        self.isup = False
        self.isdown = False
        self.walkCount = 0
        self.TypeDeterminer()
        if self.type == "Walker":
            self.speed = 4
            self.width = 80
            self.height = 85
            self.sf = 0.5
        elif self.type == "Sprinter":
            self.speed = 6
            self.width = 40
            self.height = 45
            self.sf = 0.75
        else:
            self.speed = 3
            self.width = 120
            self.height = 125
            self.sf = 0.5
            Wreckers.add(self)
        self.randomness = self.speed * 2
        self.speed = self.speed / 4
        self.x, self.y = self.spawnPos()
        self.rect = pygame.Rect(self.x, self.y, self.width * self.sf, self.height * self.sf)
        Zombie_sprites.add(self)
    def getType(self):
        return self.type
    def spawnPos(self):
        def sub():
            xpos = random.randint(0,1000 - self.width)
            ypos = random.randint(0,750 - self.height)
            return xpos, ypos
        retry = True
        while retry:
            xpos, ypos = sub()
            if (xpos < 375 - self.width) or (xpos > 625) or (ypos < 225- self.height) or (ypos > 525):
                retry = False
        return xpos, ypos
    def TypeDeterminer(self):
        Num = random.randint(1,100)
        if Num <= 50:
            self.type = "Walker"
        elif Num > 50 and Num <= 75:
            self.type = "Sprinter"
        else:
            self.type = "Wrecker"
    def getSprite(self):
        self.spriteList = []
        self.fileName = str(self.type + ".png")
        self.spriteSheet = pygame.image.load(self.fileName)
        xblocks = 0        
        yblocks = 0
        for yblocks in range (4):
            for xblocks in range (3):
                sprite = pygame.Surface((self.width, self.height))
                sprite.set_colorkey((255,255,255))
                sprite.blit(self.spriteSheet,(0,0),(xblocks*self.width, yblocks*self.height, self.width, self.height))
                smallsprite = pygame.transform.scale(sprite, (int(self.width * self.sf), int(self.height * self.sf)))
                self.spriteList.append(smallsprite)
        self.runthrough = 1
        return self.spriteList
    def update(self):
        if self.runthrough == 0:
            self.spriteList = self.getSprite()
        if self.walkCount + 1 >= 42:
            self.walkCount = 0
        walkDown = [self.spriteList[0], self.spriteList[2], self.spriteList[0], self.spriteList[2], self.spriteList[0], self.spriteList[2], ]
        walkLeft = [self.spriteList[3], self.spriteList[5], self.spriteList[3], self.spriteList[5], self.spriteList[3], self.spriteList[5], ]
        walkRight = [self.spriteList[6], self.spriteList[8], self.spriteList[6], self.spriteList[8], self.spriteList[6], self.spriteList[8], ]
        walkUp = [self.spriteList[9], self.spriteList[11], self.spriteList[9], self.spriteList[11], self.spriteList[9], self.spriteList[11], ]
        if self.isdown:
            self.image = walkDown[self.walkCount//7]
            self.walkCount += 1
        elif self.isup:
            self.image = walkUp[self.walkCount//7]
            self.walkCount += 1
        elif self.isright:
            self.image = walkRight[self.walkCount//7]
            self.walkCount += 1
        elif self.isleft:
            self.image = walkLeft[self.walkCount//7]
            self.walkCount += 1
        else:
            self.image = self.spriteList[1]
        self.MoveToPlayer()
        if pygame.sprite.spritecollideany(self, Holes):
            Zombie_sprites.remove(self)
        if pygame.sprite.spritecollideany(self, Walls):
            Sprite = pygame.sprite.spritecollideany(self, Walls)
            print(Sprite.type)
            if Sprite.type == "BouncyHorizontal":
                if Sprite.rect.y > self.rect.y:
                    self.rect.y -= self.rect.height
                elif Sprite.rect.y < self.rect.y:
                    self.rect.y += self.rect.height
                elif Sprite.rect.x > self.rect.x:
                    self.rect.x -= self.rect.height
                else:
                    self.rect.x += self.rect.height
            elif Sprite.type == "BouncyVertical":
                if Sprite.rect.y > self.rect.y:
                    self.rect.y -= self.rect.height
                elif Sprite.rect.y < self.rect.y:
                    self.rect.y += self.rect.height
                elif Sprite.rect.x > self.rect.x:
                    self.rect.x -= self.rect.height
                else:
                    self.rect.x += self.rect.height
            elif Sprite.type == "NormalHorizontal":
                if Sprite.rect.y > self.rect.y:
                    self.rect.y -= 1
                elif Sprite.rect.y < self.rect.y:
                    self.rect.y += 1
                elif Sprite.rect.x > self.rect.x:
                    self.rect.x -= 1
                else:
                    self.rect.x += 1
            else:
                if Sprite.rect.y > self.rect.y:
                    self.rect.y -= 1
                elif Sprite.rect.y < self.rect.y:
                    self.rect.y += 1
                elif Sprite.rect.x > self.rect.x:
                    self.rect.x -= 1
                else:
                    self.rect.x += 1


        

            
    
    def MoveToPlayer(self):
        if Man.rect.x > self.rect.x  and not pygame.sprite.spritecollideany(self, Walls):
            self.rect.x += self.speed
            self.rect.y += random.randint(-self.randomness, self.randomness)
            self.isleft = False
            self.isright = True
            self.isup = False
            self.isdown = False
        if Man.rect.x < self.rect.x and not pygame.sprite.spritecollideany(self, Walls):
            self.rect.x -= self.speed
            self.rect.y += random.randint(-self.randomness, self.randomness)
            self.isleft = True
            self.isright = False
            self.isup = False
            self.isdown = False
        if Man.rect.y > self.rect.y and not pygame.sprite.spritecollideany(self, Walls):
            self.rect.y += self.speed
            self.rect.x += random.randint(-self.randomness, self.randomness)
            self.isleft = False
            self.isright = False
            self.isup = False
            self.isdown = True
        if Man.rect.y < self.rect.y and not pygame.sprite.spritecollideany(self, Walls):
            self.rect.y -= self.speed
            self.rect.x += random.randint(-self.randomness, self.randomness)
            self.isleft = False
            self.isright = True
            self.isup = True
            self.isdown = False
        
class Hole(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.count = 0
        self.image = pygame.image.load("Hole.png")
        self.image.set_colorkey((255,255,255))
        self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = self.spawnPos()
        self.rect.width /= 2
        self.rect.height /= 2
        Holes.add(self)
    def update(self):
        if self.count%3.5 == 0:
            self.image = pygame.transform.rotate(self.image, 90)
        self.image.set_colorkey((255,255,255))
        self.count += 1
        if self.count > 42:
            self.count = 0
    def spawnPos(self):
        def sub():
            xpos = random.randint(0,1000 - self.rect.width)
            ypos = random.randint(0,750- self.rect.height)
            return xpos, ypos
        retry = True
        while retry:
            xpos, ypos = sub()
            if (xpos < 375 - self.rect.width) or (xpos > 625) or (ypos < 225- self.rect.height) or (ypos > 525):
                retry = False
        return xpos, ypos
class Wall(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.TypeDeterminer()
        if self.type == "NormalHorizontal":
            self.isBouncy = False
            self.image = pygame.image.load("NormalHorizontal.png")
            self.rect = self.image.get_rect()
        elif self.type == "NormalVertical":
            self.isBouncy = False
            self.image = pygame.image.load("NormalVertical.png")
            self.rect = self.image.get_rect()
        elif self.type == "BouncyHorizontal":
            self.isBouncy = True
            self.image = pygame.image.load("BouncyHorizontal.png")
            self.rect = self.image.get_rect()
        else:
            self.isBouncy = True
            self.image = pygame.image.load("BouncyVertical.png")
            self.rect = self.image.get_rect()
        self.rect.x, self.rect.y = self.spawnPos()
        print(self.rect.x, self.rect.y)
        Walls.add(self)
    def spawnPos(self):
        def sub():
            xpos = random.randint(0,1000 - self.rect.width)
            ypos = random.randint(0,750- self.rect.height)
            return xpos, ypos
        retry = True
        while retry:
            xpos, ypos = sub()
            if (xpos < 375 - self.rect.width) or (xpos > 625) or (ypos < 225- self.rect.height) or (ypos > 525):
                retry = False
        return xpos, ypos   
    def TypeDeterminer(self):
        num = random.randint(0,99)
        if num < 25:
            self.type = "NormalHorizontal"
        elif num < 50:
            self.type = "NormalVertical"
        elif num < 75:
            self.type = "BouncyHorizontal"
        else:
            self.type = "BouncyVertical"
    def update(self):
        if pygame.sprite.spritecollideany(self, Player_sprites):
            if Man.chosenCharacter == "Jake":
                Walls.remove(self)
        if pygame.sprite.spritecollideany(self, Wreckers):
            Walls.remove(self)




        
        


        


    
       


       


def redrawGameWindow():
    #xratio = 15
    #yratio = 11
    if map == "DesertMap":
        win.blit(desertMap, (0,0))
    elif map == "cityMap":
        win.blit(cityMap, (0,0))
    else:
        win.blit(grassMap, (0,0))
    Holes.update()
    Holes.draw(win)
    Walls.update()
    Walls.draw(win)
    Zombie_sprites.update()
    Zombie_sprites.draw(win)
    Man.draw()
    Player_sprites.update()
    Player_sprites.draw(win)
    text = font1.render("Lives: " + str(Man.life), True, (255,255,255))
    win.blit(text, (0,0))
    pygame.display.update()
 
def Menu():
    chosenCharacter, mode, run, CreatePlayer = IntroScreen.MainLoop(win)
    return chosenCharacter, mode, run, CreatePlayer

chosenCharacter, mode, run, CreatePlayer = Menu()
NumberOfZombies = 20
NumberOfHoles = 20
NumberOfWalls = 10
gotoMenu = False
if mode == "Endless":
   round = 0
while run:
    clock.tick(42)
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False
    if gotoMenu:
        chosenCharacter, mode, run, CreatePlayer = Menu()
        gotoMenu = False

    if CreatePlayer:
        Man = Player(chosenCharacter)
        for i in range(NumberOfZombies):
            i = Zombie()
        for i in range(NumberOfHoles):
            i = Hole()
        for i in range(NumberOfWalls):
            i = Wall()
        CreatePlayer = False
        InGame = True
      
    keys = pygame.key.get_pressed()

    if InGame:
        if keys[pygame.K_a] and Man.rect.x > Man.speed and not pygame.sprite.spritecollideany(Man, Walls):
            Man.Left()
        elif keys[pygame.K_w] and Man.rect.y > Man.speed and not pygame.sprite.spritecollideany(Man, Walls):
            Man.Up()
        elif keys[pygame.K_d] and Man.rect.x < 1000 - Man.width*Man.sf - Man.speed and not pygame.sprite.spritecollideany(Man, Walls):
            Man.Right()
        elif keys[pygame.K_s] and Man.rect.y < 750 - Man.height*Man.sf - Man.speed and not pygame.sprite.spritecollideany(Man, Walls):
            Man.Down()
        else:
            Man.Notmoving()

        if Man.life == 0:
            InGame = False
            Player_sprites.empty()
            Zombie_sprites.empty()
            Holes.empty()
            Walls.empty()
            gotoMenu = True

        if keys[pygame.K_ESCAPE]:
            InGame = False
            Player_sprites.empty()
            Zombie_sprites.empty()
            Holes.empty()
            Walls.empty()
            gotoMenu = True
        if keys[pygame.K_F3]:#dev cheat:)
            Zombie_sprites.empty()
        
        if len(Zombie_sprites) == 0 and mode == "Story":
            if map == "DesertMap":
                map = "cityMap"
                CreatePlayer = True
                NumberOfZombies = 30
                NumberOfHoles = 30
                NumberOfWalls = 30
                Player_sprites.empty()
                Zombie_sprites.empty()
                Holes.empty()
                Walls.empty()
            elif map == "cityMap":
                map = "GrassMap"
                CreatePlayer = True
                NumberOfZombies = 20
                NumberOfHoles = 10
                NumberOfWalls = 0
                Player_sprites.empty()
                Zombie_sprites.empty()
                Holes.empty()
                Walls.empty()
            else:
                Player_sprites.empty()
                Zombie_sprites.empty()
                Holes.empty()
                Walls.empty()
                gotoMenu = True
        if len(Zombie_sprites) == 0 and mode == "Endless":
            Player_sprites.empty()
            Zombie_sprites.empty()
            Holes.empty()
            Walls.empty()
            CreatePlayer = True
            NumberOfZombies += 2
            round += 1



        
   
    redrawGameWindow()
   
 
pygame.quit
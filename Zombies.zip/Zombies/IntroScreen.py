import pygame
clock = pygame.time.Clock()
bg = pygame.image.load("introscreen.png")
def initfonts():
    font1 = pygame.font.SysFont("comicsans", 30, True)
    font2 = pygame.font.SysFont("comicsans", 20)
    font3 = pygame.font.SysFont("comicsans", 50, True, True)
    return font1, font2, font3
class introscreen():
    def __init__(self):
        self.font1, self.font2, self.font3 = initfonts()
        self.run = False
        self.Story = False
        self.Endless = False
        self.chosenCharacter = "Will"
        self.CharacterAttributes = ["Will:", "Average Size", "Average Speed", "Is a rat so can tunnel"]

    def LeaderBoard(self, win):
        f = open("Leaderboard.txt", "rt")
        win.fill((255,255,255))
    def EndlessMode(self):
        self.mode = "Endless"
        self.run = True
        CreatePlayer = True
        return self.chosenCharacter, self.mode, self.run , CreatePlayer
    def StoryMode(self):
        self.run = True
        self.mode = "Story"
        CreatePlayer = True
        return self.chosenCharacter, self.mode, self.run, CreatePlayer
    def ChooseCharacter(self):
        if self.chosenCharacter == "Jake":
            self.chosenCharacter = "Will"
            self.CharacterAttributes = ["Will:", "Average Size", "Average Speed", "Is a rat so can tunnel"]
        elif self.chosenCharacter == "Will":
            self.chosenCharacter = "Noah"
            self.CharacterAttributes = ["Noah:", "Small", "Quick", "Prone to injury"]
        elif self.chosenCharacter == "Noah":
            self.chosenCharacter = "Jake"
            self.CharacterAttributes = ["Jake:", "BIG", "Slow", "Can break weak Walls"]
        return self.chosenCharacter
    
    def MainLoop(self, win):
        runIntro = True
        Story = ["Story"]
        Endless = ["Endless"]
        Leaderboard = ["LeaderBoard"]
        while runIntro:
            clock.tick(42)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    runIntro= False
                    return self.chosenCharacter, self.Story, False, False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    buttonPressed = pygame.mouse.get_pressed()
                    if buttonPressed == (True, False, False):
                        pos = pygame.mouse.get_pos()
                        if pos[0] >= 100 and pos[0] <= 400 and pos[1] >= 240 and pos[1] <= 440:
                            return self.StoryMode()
                        elif pos[0] >= 100 and pos[0] <= 400 and pos[1] >= 450 and pos[1] <= 650:
                            return self.EndlessMode()
                        elif pos[0] >= 600 and pos[0] <= 900 and pos[1] >= 240 and pos[1] <= 340:
                            self.ChooseCharacter()
                        elif pos[0] >= 600 and pos[0] <= 900 and pos[1] >= 550 and pos[1] <= 650:
                            self.LeaderBoard(win)
            ChosenChar = [self.chosenCharacter, "Click To Change"]       
            win.blit(bg, (0,0))
            StoryRectangle = ButtonMaker(200, 100, Story, self.font1)
            EndlessRectangle = ButtonMaker(200, 100, Endless, self.font1)
            ChosenCharacterRectangle = ButtonMaker(100, 100, ChosenChar, self.font1)
            CharacterAttributesRectangle = ButtonMaker(200, 50, self.CharacterAttributes, self.font2)
            LeaderboardRectangle = ButtonMaker(100, 100, Leaderboard, self.font1)
            text = self.font3.render("ZOMBIES", 1, (0,200,0))
            win.blit(text, (400, 50))
            win.blit(StoryRectangle, (100, 240))
            win.blit(EndlessRectangle, (100, 450))
            win.blit(ChosenCharacterRectangle, (600, 240))
            win.blit(CharacterAttributesRectangle, (600, 340))
            win.blit(LeaderboardRectangle, (600, 550))
            pygame.display.update()

def ButtonMaker(h, alpha, string, font):
    layer = pygame.Surface((300, h))
    layer.set_alpha(alpha)
    layer.fill((1,0,0))
    for i in range (len(string)):
        text = font.render(string[i], 1, (0,150,0))
        layer.blit(text,(0,30*i))
    return layer

pygame.quit()